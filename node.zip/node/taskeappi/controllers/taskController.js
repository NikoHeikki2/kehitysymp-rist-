var Task = require('../models/Task'); 


exports.task_list = function(req,res,next) { 
    var taskList=[]; 
    Task.getAllTasks(function(err, rows, fields) {  
        if (err) {  
        return next(err); } 
        for (var i = 0; i < rows.length; i++) { 

            // Create an object to save current row's data 
            var task = { 
                'id':rows[i].id, 
                'title':rows[i].title, 
                'status':rows[i].status, 
            } 
            // Add object into array 
            taskList.push(task); 
        } 

            // Render index.pug page using array  
        res.render('task', {title:'TODO',taskList:taskList}); 
    }); 
}; 